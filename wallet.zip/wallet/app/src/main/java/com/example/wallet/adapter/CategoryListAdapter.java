package com.example.wallet.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.wallet.R;
import com.example.wallet.model.Category;

public class CategoryListAdapter extends ArrayAdapter<Category> {
    private Category[] categories;

    public CategoryListAdapter(@NonNull Context context, int resource, @NonNull Category[] objects) {
        super(context, resource, objects);
        this.categories = objects;
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        TextView name = convertView.findViewById(R.id.name);
        name.setText(this.categories[position].name);
        // TODO: add image
        return convertView;
    }
}
