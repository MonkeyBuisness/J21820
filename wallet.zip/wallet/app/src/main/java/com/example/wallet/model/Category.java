package com.example.wallet.model;

public class Category {
    public String name;
    public int logoId;
}
